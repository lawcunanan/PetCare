import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../../styles/Auth.css";
import { signupUser } from "../../firebase/function/insert/signupUser";
import { LoadingSpinner } from "../../view/component/loading";

const Signup = () => {
	const [loading, setBtnloading] = useState(false);
	const [name, setName] = useState("");
	const [profileImageUrl, setProfileImageUrl] = useState("");
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [confirmPassword, setConfirmPassword] = useState("");

	const handleSubmit = async (e) => {
		e.preventDefault();

		if (password !== confirmPassword) {
			alert("Passwords do not match!");
			return;
		}

		await signupUser({ name, email, password, profileImageUrl }, setBtnloading);

		setName("");
		setProfileImageUrl("");
		setEmail("");
		setPassword("");
		setConfirmPassword("");
	};

	return (
		<div className="auth-container">
			<h2>PetCare Sign Up 🐾</h2>

			<form onSubmit={handleSubmit} className="email-form">
				<input
					type="text"
					placeholder="Full Name"
					value={name}
					onChange={(e) => setName(e.target.value)}
					required
				/>

				<input
					type="url"
					placeholder="Profile Image URL"
					value={profileImageUrl}
					onChange={(e) => setProfileImageUrl(e.target.value)}
					required
				/>

				{profileImageUrl && (
					<img
						src={profileImageUrl}
						alt="Profile Preview"
						className="profile-preview"
						onError={(e) => {
							e.target.onerror = null;
							e.target.src = "https://via.placeholder.com/150?text=Invalid+URL";
						}}
					/>
				)}

				<input
					type="email"
					placeholder="Email"
					value={email}
					onChange={(e) => setEmail(e.target.value)}
					required
				/>

				<input
					type="password"
					placeholder="Password"
					value={password}
					onChange={(e) => setPassword(e.target.value)}
					required
				/>

				<input
					type="password"
					placeholder="Confirm Password"
					value={confirmPassword}
					onChange={(e) => setConfirmPassword(e.target.value)}
					required
				/>

				<button type="submit" disabled={loading}>
					{loading ? <LoadingSpinner loading={loading} /> : "Sign up"}
				</button>
			</form>

			<div className="toggle-link">
				Already have an account? <Link to="/signin">Login here</Link>
			</div>
		</div>
	);
};

export default Signup;
