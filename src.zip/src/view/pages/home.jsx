// src/pages/Home.jsx
import { useNavigate } from "react-router-dom";

const Home = () => {
	const navigate = useNavigate();

	return (
		<div className="home-container">
			<h1>Welcome to My Vite + React App</h1>
			<p>This is the home page.</p>
			<div className="button-group">
				<button onClick={() => navigate("/signin")}>Login</button>{" "}
				<button onClick={() => navigate("/signup")}>Sign Up</button>
			</div>
		</div>
	);
};

export default Home;
