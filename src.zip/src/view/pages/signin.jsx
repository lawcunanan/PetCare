import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../../styles/Auth.css";
import { LoadingSpinner } from "../component/loading";

import { signEmailPass } from "../../firebase/function/insert/signinEmailPass";
import { signinGoogle } from "../../firebase/function/insert/signinGoogle";

const Signin = () => {
	const [loading, setBtnloading] = useState(false);
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");

	const handleSubmit = async (e) => {
		e.preventDefault();
		setBtnloading(true);
		try {
			await signEmailPass(email, password, setBtnloading);
		} catch (error) {
			alert(error.message);
			setBtnloading(false);
		}
	};

	const handleGoogleSignIn = async () => {
		setBtnloading(true);
		try {
			await signinGoogle(setBtnloading);
		} catch (error) {
			alert(error.message);
			setBtnloading(false);
		}
	};

	return (
		<div className="auth-container">
			<h2>PetCare Login 🐾</h2>

			<button
				className="google-btn"
				onClick={handleGoogleSignIn}
				disabled={loading}
			>
				<img
					src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/google/google-original.svg"
					alt="Google"
				/>
				{loading ? <LoadingSpinner loading={loading} /> : "Sign in with Google"}
			</button>

			<hr />

			<form onSubmit={handleSubmit} className="email-form">
				<input
					type="email"
					placeholder="Email"
					value={email}
					onChange={(e) => setEmail(e.target.value)}
					required
					disabled={loading}
				/>
				<input
					type="password"
					placeholder="Password"
					value={password}
					onChange={(e) => setPassword(e.target.value)}
					required
					disabled={loading}
				/>
				<button type="submit" disabled={loading}>
					{loading ? <LoadingSpinner loading={loading} /> : "Login"}
				</button>
			</form>

			<p>
				New to PetCare?{" "}
				<Link to="/signup" className="toggle-link">
					Create account
				</Link>
			</p>
		</div>
	);
};

export default Signin;
