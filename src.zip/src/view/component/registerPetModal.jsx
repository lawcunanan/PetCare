import React, { useEffect, useState } from "react";
import "../../styles/RegisterPetModal.css";
import { LoadingSpinner } from "../component/loading";
import { addPet } from "../../firebase/function/insert/addPet";
import { useUser } from "../../context/userContext";
import { useChat } from "../../context/chatContext";
import updatePet from "../../firebase/function/update/updatePet";

const RegisterPetModal = ({ show, handleClose, mode = "register" }) => {
	const { userDetails } = useUser();
	const { petDetails } = useChat();
	const [loading, setBtnloading] = useState(false);
	const [petData, setPetData] = useState({
		name: "",
		species: "",
		breed: "",
		gender: "",
		weight: "",
		profileImage: "",
		healthIssues: [],
	});

	const [healthIssue, setHealthIssue] = useState({
		type: "",
		description: "",
	});

	const handlePetChange = (e) => {
		setPetData({ ...petData, [e.target.name]: e.target.value });
	};

	const handleIssueChange = (e) => {
		setHealthIssue({ ...healthIssue, [e.target.name]: e.target.value });
	};

	const addHealthIssue = () => {
		if (!healthIssue.type.trim()) return;
		setPetData({
			...petData,
			healthIssues: [...petData.healthIssues, { ...healthIssue }],
		});
		setHealthIssue({ type: "", description: "" });
	};

	const removeHealthIssue = (index) => {
		const newIssues = petData.healthIssues.filter((_, i) => i !== index);
		setPetData({ ...petData, healthIssues: newIssues });
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		if (mode == "register") {
			await addPet(userDetails.uid, petData, setBtnloading);
		} else {
			await updatePet(petData.id, petData, petData.chatHistory, setBtnloading);
		}

		setPetData([]);
		handleClose();
	};

	useEffect(() => {
		if (petDetails && mode === "edit") {
			setPetData(petDetails);
		}
	}, [mode, petDetails]);

	if (!show) return null;

	return (
		<div className="register-pet modal-overlay">
			<div className="modal-box">
				<div className="modal-header">
					<h2>{mode === "edit" ? "Edit Pet" : "Register Pet"}</h2>
					<button className="close-btn" onClick={handleClose}>
						&times;
					</button>
				</div>

				<form onSubmit={handleSubmit} className="modal-body">
					<h3>Pet Information</h3>
					<div className="form-grid">
						<input
							type="text"
							name="name"
							placeholder="Name"
							value={petData.name}
							onChange={handlePetChange}
							required
						/>

						<select
							name="species"
							value={petData.species}
							onChange={handlePetChange}
							required
						>
							<option value="">Select Species</option>
							<option value="Dog">Dog</option>
							<option value="Cat">Cat</option>
						</select>
						<input
							type="text"
							name="breed"
							placeholder="Breed"
							value={petData.breed}
							onChange={handlePetChange}
						/>
						<select
							name="gender"
							value={petData.gender}
							onChange={handlePetChange}
							required
						>
							<option value="">Select Gender</option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
						</select>
						<input
							type="number"
							name="weight"
							placeholder="Weight (kg)"
							value={petData.weight}
							onChange={handlePetChange}
							min="0"
						/>
						<input
							type="url"
							name="profileImage"
							placeholder="Profile Image URL"
							value={petData.profileImage}
							onChange={handlePetChange}
						/>
					</div>

					<h3>Health Issue</h3>
					<div className="form-grid">
						<input
							type="text"
							name="type"
							placeholder="Issue Type"
							value={healthIssue.type}
							onChange={handleIssueChange}
						/>
						<textarea
							name="description"
							placeholder="Description"
							value={healthIssue.description}
							onChange={handleIssueChange}
							rows={3}
						/>
					</div>
					<button
						type="button"
						className="add-issue-btn"
						onClick={addHealthIssue}
					>
						Add Health Issue
					</button>

					{petData.healthIssues.length > 0 && (
						<>
							<h3>Added Health Issues</h3>
							<ul className="issue-list">
								{petData.healthIssues.map((issue, index) => (
									<li key={index}>
										<strong>{issue.type}</strong> - {issue.description}
										<button
											type="button"
											onClick={() => removeHealthIssue(index)}
										>
											Remove
										</button>
									</li>
								))}
							</ul>
						</>
					)}

					<div className="modal-footer">
						<button type="button" className="cancel-btn" onClick={handleClose}>
							Cancel
						</button>
						<button type="submit" className="submit-btn" disabled={loading}>
							{loading ? (
								<LoadingSpinner loading={loading} />
							) : mode === "edit" ? (
								"Update Pet"
							) : (
								"Register Pet"
							)}
						</button>
					</div>
				</form>
			</div>
		</div>
	);
};

export default RegisterPetModal;
